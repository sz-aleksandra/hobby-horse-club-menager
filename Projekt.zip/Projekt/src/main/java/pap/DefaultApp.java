package pap;

import pap.gui.SignUpLogIn.LogInGUI;

public class DefaultApp {
    public static void main(String[] args) {
        LogInGUI.main(args);
    }
}
